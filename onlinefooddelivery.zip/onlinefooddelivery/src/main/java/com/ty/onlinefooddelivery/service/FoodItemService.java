package com.ty.onlinefooddelivery.service;


import com.ty.onlinefooddelivery.entity.FoodItem;
import com.ty.onlinefooddelivery.entity.Product;
import com.ty.onlinefooddelivery.repository.FoodItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FoodItemService {

	@Autowired
    private FoodItemRepository foodItemRepository;

    public List<FoodItem> getAllFoodItems() {
        return foodItemRepository.findAll();
    }

    public void saveFoodItem(FoodItem foodItem) {
        foodItemRepository.save(foodItem);
    }

    public List<FoodItem> getFoodItemsByIds(List<Long> ids) {
        return foodItemRepository.findAllById(ids);
    }

    public Optional<FoodItem> getFoodItemById(Long id) {
        return foodItemRepository.findById(id);
    }
    public void updateFoodItem(FoodItem foodItem) {
        foodItemRepository.save(foodItem);
    }

    public void deleteFoodItem(Long id) {
        foodItemRepository.deleteById(id);
    }
}

