package com.ty.onlinefooddelivery.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ty.onlinefooddelivery.entity.Cart;
import com.ty.onlinefooddelivery.entity.FoodItem;
import com.ty.onlinefooddelivery.entity.Online;
import com.ty.onlinefooddelivery.entity.Order;
import com.ty.onlinefooddelivery.entity.Product;
import com.ty.onlinefooddelivery.entity.User;
import com.ty.onlinefooddelivery.repository.OrderRepository;
import com.ty.onlinefooddelivery.service.FoodItemService;
import com.ty.onlinefooddelivery.service.ProductService;
import com.ty.onlinefooddelivery.service.UserService;
import com.ty.onlinefooddelivery.service.foodservice;

import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {
	
	@Autowired
    private foodservice foodservice;
	@Autowired
	private FoodItemService foodItemService;
	
	@Autowired
    private UserService userService;

    @GetMapping("/register")
    public String showRegistrationPage(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute("user") User user, Model model) {
        if (userService.checkIfUserExists(user.getUsername(), user.getEmail())) {
            model.addAttribute("error", "Username or Email already exists.");
            return "register";
        }
        userService.registerUser(user);
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String showLoginPage(Model model) {
        model.addAttribute("user", new User());
        return "login";
    }

    @PostMapping("/login")
    public String loginUser(@ModelAttribute("user") User user, Model model) {
        User existingUser = userService.findByUsername(user.getUsername());
        if (existingUser != null && userService.checkPassword(existingUser, user.getPassword())) {
            return "redirect:/index";
        } else {
            model.addAttribute("error", "Invalid username or password.");
            return "login";
        }
    }
	@GetMapping("/shoppingcart")
	public String shoppingcart() {
		return "shoppingcart";
	}
	@GetMapping("/home")
	public String home() {
		return "home";
	}
	
	@GetMapping("/contact")
	public String contact() {
		return "contact";
	}
	
	@GetMapping("/index")
	public String index() {
		return "index";
	}
	
	@GetMapping("/checkout")
	public String checkout() {
		return "checkout";
	}
    
 
    @Autowired
    private ProductService productService;
    
    @GetMapping("/product-list")
    public String productlist() {
        return "product-list"; 
    }

    @GetMapping("/product-details")
	public String productdetails() {
		return "product-details";
	}
	@GetMapping("/pizza")
	public String pizza() {
		return "pizza";
	}
	@GetMapping("/burger")
	public String burger() {
		return "burger";
	}
	@GetMapping("/dosa")
	public String dosa() {
		return "dosa";
	}
	@GetMapping("/biryani")
	public String biryani() {
		return "biryani";
	}
	@GetMapping("/product-overview")
	public String productoverview() {
		return "product-overview";
	}

	@GetMapping("/checkout-2")
	public String checkout2() {
		return "checkout-2";
	}
	@GetMapping("/checkout-3")
	public String checkout3() {
		return "checkout-3";
	}
	@GetMapping("/checkout-4")
	public String checkout4() {
		return "checkout-4";
	}
	@GetMapping("/checkout-5")
	public String checkout5() {
		return "checkout-5";
	}

	@GetMapping("/order")
	public String order() {
		return "order";
	}
	@GetMapping("/bank-details")
	public String bankdetails() {
		return "bank-details";
	}
	@GetMapping("/credit_card")
	public String creditcard() {
		return "credit_card";
	}
	@GetMapping("/cash")
	public String cash() {
		return "cash";
	}
	 @GetMapping("/food-list")
	    public String foodlist(Model model) {
	        model.addAttribute("foodItems", foodItemService.getAllFoodItems());
	        return "food-list";
	    }

	    @PostMapping("/food-list")
	    public String addFoodItem(@RequestParam("name") String name, 
	                              @RequestParam("imageUrl") String imageUrl, 
	                              @RequestParam("description") String description, 
	                              @RequestParam("price") double price) {
	        FoodItem foodItem = new FoodItem();
	        foodItem.setName(name);
	        foodItem.setImageUrl(imageUrl);
	        foodItem.setDescription(description);
	        foodItem.setPrice(price);
	        foodItemService.saveFoodItem(foodItem);
	        return "redirect:/food-list";
	    }

	    @PostMapping("/cart")
	    public String addToCart(@RequestParam Long id, HttpSession session, RedirectAttributes redirectAttributes) {
	        List<Long> cart = (List<Long>) session.getAttribute("cart");
	        if (cart == null) {
	            cart = new ArrayList<>();
	        }
	        cart.add(id);
	        session.setAttribute("cart", cart);
	        redirectAttributes.addFlashAttribute("message", "Item added to cart");
	        return "redirect:/cart"; // Redirect to the food list or any appropriate page
	    }

	    @GetMapping("/cart")
	    public String viewCart(HttpSession session, Model model) {
	        List<Long> cart = (List<Long>) session.getAttribute("cart");
	        List<FoodItem> cartItems = new ArrayList<>();
	        if (cart != null) {
	            cartItems = foodItemService.getFoodItemsByIds(cart);
	        }
	        model.addAttribute("cartItems", cartItems);
	        return "cart";
	    }

	    @GetMapping("/order_confirmation")
	    public String orderConfirmation() {
	        // Add any necessary logic for order confirmation
	        return "order_confirmation";
	    }

	}
