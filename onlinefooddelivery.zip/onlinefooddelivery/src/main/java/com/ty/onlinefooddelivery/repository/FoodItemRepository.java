package com.ty.onlinefooddelivery.repository;



import com.ty.onlinefooddelivery.entity.FoodItem;


import org.springframework.data.jpa.repository.JpaRepository;

public interface FoodItemRepository extends JpaRepository<FoodItem, Long> {
}
