package com.ty.onlinefooddelivery.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.stereotype.Service;

import com.ty.onlinefooddelivery.entity.FoodItem;
import com.ty.onlinefooddelivery.entity.Online;
import com.ty.onlinefooddelivery.repository.*;


@Service
public class foodservice {

    @Autowired
    private foodrepository foodrepository;

    public  Object save(Online user) {
        return foodrepository.save(user);
    }

    public Online findByUsername(String username) {
        return com.ty.onlinefooddelivery.repository.foodrepository.findByUsername(username);
    }
    public boolean usernameExists(String username) {
        return findByUsername(username) != null;
    }

    public boolean authenticate(String username, String password) {
        Online user = findByUsername(username);
        return user != null && user.getPassword().equals(password);
    }
    public List<Online> getAllfoods(){
    	return foodrepository.findAll();
    }

	public List<FoodItem> getFoodItemsByIds(List<Long> cart) {
		// TODO Auto-generated method stub
		return null;
	}

	

	
	
	
}
