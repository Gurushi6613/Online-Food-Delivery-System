package com.ty.onlinefooddelivery.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ty.onlinefooddelivery.entity.Admin;
import com.ty.onlinefooddelivery.entity.FoodItem;
import com.ty.onlinefooddelivery.service.AdminService;
import com.ty.onlinefooddelivery.service.FoodItemService;
import com.ty.onlinefooddelivery.service.ProductService;
import com.ty.onlinefooddelivery.service.foodservice;

@Controller
public class AdminController {

    @Autowired
    private AdminService adminService;
    @Autowired
    private FoodItemService foodItemService;

    @GetMapping("/admin-login")
    public String adminLoginPage() {
        return "admin-login";
    }

    @PostMapping("/admin-login")
    public String adminLogin(@RequestParam("username") String username, 
                             @RequestParam("password") String password, Model model) {
        Admin admin = adminService.findByUsername(username);
        if (admin != null && admin.getPassword().equals(password)) {
            return "redirect:/admin-login";
        } else {
            model.addAttribute("error", "Invalid username or password");
            return "admin-dashboard";
        }
    }

    @GetMapping("/admin-dashboard")
    public String adminDashboard(Model model) {
        model.addAttribute("foodItems", foodItemService.getAllFoodItems());
        return "admin-dashboard";
    } 
    
}
