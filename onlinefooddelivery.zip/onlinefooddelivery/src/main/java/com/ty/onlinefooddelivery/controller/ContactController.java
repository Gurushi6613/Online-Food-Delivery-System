package com.ty.onlinefooddelivery.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ContactController {

    @PostMapping("/contact-success")
    public ModelAndView submitContactForm(
            @RequestParam("name") String name,
            @RequestParam("email") String email,
            @RequestParam("message") String message) {

        // Handle form submission logic here (e.g., save to database, send email)

        // For demonstration purposes, we'll just show a success page
        ModelAndView mav = new ModelAndView("contact-success");
        mav.addObject("name", name);
        return mav;
    }
}

