package com.ty.onlinefooddelivery.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ty.onlinefooddelivery.entity.Order;
import com.ty.onlinefooddelivery.repository.OrderRepository;

public class OrderController {
	@GetMapping("/add")
	public String add() {
		return "add";
	}
	
	@Autowired
    private OrderRepository orderRepository;

    @GetMapping("/order")
    public ModelAndView addToCart(@RequestParam String name, @RequestParam String description, @RequestParam double price) {
        // Create new order instance
        Order order = new Order();
        order.setName(name);
        order.setDescription(description);
        order.setPrice(price);

        // Save order to repository (example: assuming you want to save to DB)
        orderRepository.save(order);

        // Redirect to checkout page
        return new ModelAndView("redirect:/add");
    }
    @GetMapping("/add")
    public String getItemDetails(
            @RequestParam("id") String id,
            @RequestParam("name") String name,
            @RequestParam("price") String price,
            Model model) {

        model.addAttribute("id", id);
        model.addAttribute("name", name);
        model.addAttribute("price", price);

        return "add";
    }
    

  

    
}
