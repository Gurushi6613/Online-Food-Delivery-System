package com.ty.onlinefooddelivery.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ty.onlinefooddelivery.entity.User;
import com.ty.onlinefooddelivery.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User registerUser(User user) {
        // Directly save the password without encoding
        return userRepository.save(user);
    }

    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public User findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public boolean checkIfUserExists(String username, String email) {
        return findByUsername(username) != null || findByEmail(email) != null;
    }

    public boolean checkPassword(User user, String rawPassword) {
        // Directly compare the raw password with the stored password
        return rawPassword.equals(user.getPassword());
    }
}
