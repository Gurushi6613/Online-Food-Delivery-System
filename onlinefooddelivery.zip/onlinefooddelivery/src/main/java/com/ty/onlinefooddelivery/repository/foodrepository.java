package com.ty.onlinefooddelivery.repository;
import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.data.jpa.repository.JpaRepository;


import org.springframework.stereotype.Repository;

import com.ty.onlinefooddelivery.entity.Online;

@Repository
public interface foodrepository extends JpaRepository<Online, Integer>{

	  static Online findByUsername(String username) {
		// TODO Auto-generated method stub
		return null;
	}

	Object save(User user);
	
	
}
